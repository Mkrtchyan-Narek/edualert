import { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  DialogActions,
} from '@mui/material';
import {
  doc,
  getDoc,
  updateDoc
} from "firebase/firestore";
import { db } from "../firebase.js";

export default function ModalDialog({ classCode, open, onClose, sign }) {

  const [input, setInput] = useState("");

  useEffect(() => {
    setInput("");
  }, [open])

  const handleSubmit = async () => {
    const docSnap = await getDoc(doc(db, "164", classCode));
    let newHomeworks = docSnap.data().homeworks;
    if(sign == "-") {
      if(!newHomeworks[input]) {
        setInput("Չկա նման առարկա");
        return;
      }
      delete newHomeworks[input];
    } else {
      if(newHomeworks[input]) {
        setInput("Արդեն կա");
        return;
      }
      newHomeworks[input] = {url: "", text: ""};
    }
    updateDoc(doc(db, "164", classCode), {homeworks: newHomeworks});
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>{(sign == "-") ? "Առարկայի Հեռացում" : "Առարկայի Ավելացում"}</DialogTitle>
      <DialogContent>
        <TextField
          multiline
          rows={4}
          placeholder="Գրեք..."
          fullWidth
          value={input}
          onChange={(e) => setInput(e.target.value)}
          sx={{ mb: 2 }}
        />
      </DialogContent>
      <DialogActions>
        <Button onClick={handleSubmit} variant="contained" sx={{ backgroundColor: '#26b8b8', '&:hover': { backgroundColor: '#1ea0a0' } }}>
          Պահպանել
        </Button>
        <Button onClick={onClose} sx={{ backgroundColor: '#ffffff' }}>
          Փակել
        </Button>
      </DialogActions>
    </Dialog>
  );
}
